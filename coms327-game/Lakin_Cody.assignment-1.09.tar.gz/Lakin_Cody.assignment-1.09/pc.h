#ifndef PC_H
# define PC_H

# include <stdint.h>

# include "dims.h"
# include "character.h"
# include "dungeon.h"

typedef enum equipment_objects {
  weapon,
  offhand,
  ranged,
  light,
  armor,
  helmet,
  cloak,
  gloves,
  boots,
  amulet,
  ring_one,
  ring_two,
  num_items
} equipment_objects_t;

typedef object* equipment_t[num_items];

class pc : public character {
 private:
  int find_carry_slot();
  int find_equipment_slot(object* item);
  void remove_item_stats(object* item);
  void add_item_stats(object* item);
 public:
  inline pc() {hp_modifier = speed_modifier = 0;}
  ~pc() {}
  object* inv[10];
  equipment_t equipment;
  int hp_modifier, speed_modifier;
  terrain_type_t known_terrain[DUNGEON_Y][DUNGEON_X];
  uint8_t visible[DUNGEON_Y][DUNGEON_X];
  void equip_item(int slot);
  void unequip_item(int slot);
  void drop_item(dungeon* d, int slot);
  void destroy_item(int slot);
  void pickup_item(dungeon* d);
  int calculate_damage();
};

void pc_delete(pc *pc);
uint32_t pc_is_alive(dungeon *d);
void config_pc(dungeon *d);
uint32_t pc_next_pos(dungeon *d, pair_t dir);
void place_pc(dungeon *d);
uint32_t pc_in_room(dungeon *d, uint32_t room);
void pc_learn_terrain(pc *p, pair_t pos, terrain_type_t ter);
terrain_type_t pc_learned_terrain(pc *p, int16_t y, int16_t x);
void pc_init_known_terrain(pc *p);
void pc_observe_terrain(pc *p, dungeon *d);
int32_t is_illuminated(pc *p, int16_t y, int16_t x);
void pc_reset_visibility(pc *p);

#endif
