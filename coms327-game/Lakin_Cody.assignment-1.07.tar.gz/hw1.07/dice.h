#ifndef DICE_H
# define DICE_H

# include <string>

class dice {
 public:
  int base;
  int num_dice;
  int sides;
  dice();
  dice(int given_base, int given_dice, int given_sides);
  ~dice();
  std::string to_string();
};

#endif
