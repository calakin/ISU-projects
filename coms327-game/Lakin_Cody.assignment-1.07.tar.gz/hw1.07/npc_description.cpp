#include "npc_description.h"
#include <stdlib.h>
//#include "npc.h"

using namespace std;

npc_description::npc_description(string given_name, 
				 string given_description,
				 string given_color,
				 dice given_speed,
				 string given_abilities,
				 dice given_atk,
				 dice given_hp,
				 char given_symbol){
  name = given_name;
  description = given_description;
  color = given_color;
  speed = (dice *)malloc(sizeof(dice));
  *speed = given_speed;
  abilities = given_abilities;
  atk = (dice *)malloc(sizeof(dice));
  *atk = given_atk;
  hp = (dice *)malloc(sizeof(dice));
  *hp = given_hp;
  symbol = given_symbol;
}

npc_description::~npc_description()
{
  free(speed);
  free(atk);
  free(hp);
}

string npc_description::to_string()
{
  string s = "";

  s += name;
  s += description;
  s += symbol;
  s += '\n';
  s += color;
  s += speed->to_string();
  s += abilities;
  s += hp->to_string();
  s += atk->to_string();
  s += '\n';

  return s;
}
