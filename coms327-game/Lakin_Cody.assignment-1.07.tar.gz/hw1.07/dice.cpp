#include <iostream>
#include "dice.h"
#include <sstream>

using namespace std;

namespace patch
{
    template < typename T > std::string to_string( const T& n )
    {
        std::ostringstream stm ;
        stm << n ;
        return stm.str() ;
    }
}

dice::dice()
{
  base = 0;
  num_dice = 0;
  sides = 0;
}

dice::dice(int given_base, int given_dice, int given_sides)
{
  base = given_base;
  num_dice = given_dice;
  sides = given_sides;
}

dice::~dice()
{
}

string dice::to_string()
{
  string s = "";
  
  s += patch::to_string(base);
  s += "+";
  s += patch::to_string(num_dice);
  s += "d";
  s += patch::to_string(sides);
  s += "\n";

  return s;
}
