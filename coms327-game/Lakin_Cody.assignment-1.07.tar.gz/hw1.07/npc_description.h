#ifndef NPC_DESCRIPTION_H
# define NPC_DESCRIPTION_H

# include "dice.h"

class npc;

class npc_description
{
 public:
  std::string name;
  std::string description;
  std::string color;
  std::string abilities;
  dice *speed;
  dice *atk;
  dice *hp;  
  char symbol;
  npc_description(std::string given_name, 
		  std::string given_description,
		  std::string given_color,
		  dice given_speed,
		  std::string given_abilities,
		  dice given_atk,
		  dice given_hp,
		  char given_symbol);
  ~npc_description();
  std::string to_string();
  //npc_t generate_npc();
};



#endif
