import java.util.Scanner;
import java.net.*;
import java.lang.Character;
import java.lang.Object;
import javax.swing.ImageIcon;
import javax.imageio.ImageIO;
import java.time.*;
import java.io.*;
import java.awt.*;
import java.awt.image.*;

public class MyClient
{
    Socket socket;
    String serverHostName = "localHost";
    int serverPortNumber = 4444;
    ServerListener s1;
    String name;
    Scanner scanUser;
    PrintWriter printToServer;

    //server starts
    //server waits for clients
    //client starts
    //client requests user's name
    //client saves entered name
    //client connects to server
    //client begins listening to server
    //server begins listening to the client, also continues waiting for other clients
    //client begins listening to the user
    //client displays a menu for the user
    //client continuously waits for user command until given the exit command
    //client responds appropriately when one of the valid commands is given from the user

    //client stops listening and shuts down if receives first char of line is 0
    //client sendsText() if first char is 1 and the message is the following part of string
    //client sendsImage() if first char is 2 and
    //client displays menu again if first char is -1

    //whatever is to be send (text or image) is then sent through the connection to the server
    //Client handler receives, tells server to send and save appropriately

    //when other clients receive messages from server, they may need another thread to avoid lag
    
    
    public MyClient()
    {
	try{    
	    //connect to server
	    this.socket = new Socket(serverHostName, serverPortNumber);

	    //scanner for user input
	    this.scanUser = new Scanner(System.in);

	    requestName();
	    
	    //printwriter to server
	    this.printToServer = new PrintWriter(new BufferedOutputStream(socket.getOutputStream()));
	    
	} catch(UnknownHostException e) {
	    e.printStackTrace();
	} catch(IOException e){
	    e.printStackTrace();
	}
        s1 = new ServerListener(this, socket);
	startListeningToServer();

	//start listening to user
	listenToUser();
    }

    public void listenToUser(){
	
	int choice = -1;
	
	while(choice != 0){

	    String message;
	    String tmp;

	    if(choice == -1){
		displayMenu();
	    }
	    
	    tmp = getUserCommand();
	    message = "" + tmp.substring(0,2) + name + ": " + tmp.substring(2);
	    
	    choice = Character.getNumericValue( message.charAt(0));
	    
	    switch(choice) {
	    case 1:
		sendTextMessage(message);
		break;
	    case 2:
		sendImageFile(message);
		break;
	    default:
		System.out.println("Client: Not a valid entry. Please retry.");
	        choice = -1;
		break;
	    }
	}
    }

    public static void main(String[] args)
    {
	MyClient client = new MyClient();
    }
  

    public void exitClient(){

	scanUser.close();
	
	printToServer.println("0");

	printToServer.close();
	try{
	    socket.close();
	} catch (IOException e){
	    e.printStackTrace();
	}

	System.out.println("Goodbye");
    }

    public void sendTextMessage(String message)
    {
	    printToServer.println(message);
	    printToServer.flush();
    }

    public void sendImageFile(String message)
    {
	String filepath, filename;
	File file;

	//parse filepath
	filepath = message.substring(name.length() + 4);

	file = new File(filepath);

	//parse the filename
	//	filename = filepath.substring(filepath.lastIndexOf('/') + 1);

	//send filename as message
        printToServer.println(message);
	printToServer.flush();

	try{
	    
	//send the image
        ImageIcon img = new ImageIcon(ImageIO.read(file));
	ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
	out.writeObject(img);
	
	} catch(IOException e){
	    e.printStackTrace();
	}
    }

    public void displayAdminMenu(){
	
    }
    
    public void displayMenu()
    {
	System.out.println("Welcome to the chat. Below are your options:");
	System.out.println("1. Send a text message to the server");
	System.out.println("2. Send an image file to the server");
	System.out.println("Respond by entering the number of your choice (i.e. '1'), a space, and then your message/image filepath.");
    }

    public String getUserCommand()
    {
	String message = this.scanUser.nextLine();
	
	return message;
    }

    public void requestName()
    {
	System.out.println("Enter your name: (type your name, then enter)");
	this.name = this.scanUser.nextLine();
    }

    public void startListeningToServer()
    {
	new Thread(s1).start();
    }


    //MAY need to create yet another thread to do this, as ServerListener must listen to server
    //and the client must listen to the user
    public void handleServerInput(String givenInput)
    {
	int command = Character.getNumericValue(givenInput.charAt(0));
	    
	switch(command){
	    
	//print a text message from other clients
	case 1:
	    System.out.println(givenInput.substring(2));
	    break;
	    
	//save an image
	case 2:
	    System.out.println(givenInput.substring(2));
	    String senderName = givenInput.substring(2, givenInput.indexOf(':'));
	    String filename = givenInput.substring((senderName.length() + 4));
	    receiveImage(filename, senderName);
	    break;
	    
	default:
	    System.out.println("Client: Unknown command received from server");
	    break;
	}
    }

	public void receiveImage(String filename, String senderName)
	{
	    String hour = ("" + LocalTime.now()).substring(0,2);
	    String minute = ("" + LocalTime.now()).substring(3, 5);
	    ImageIcon img;
	    String formatName = filename.substring(filename.length() - 3);
	    
	    String newFilename = filename.substring(0, filename.length()-4) + '_' + senderName + '_' + hour + '_' + minute + '_' + name;

	    try{
		
	       File file = new File(newFilename + ".jpg");
	       file.createNewFile();

	        ObjectInputStream objectIn = new ObjectInputStream(socket.getInputStream());
		img = (ImageIcon)objectIn.readObject();

		BufferedImage bImg = new BufferedImage(
						       img.getIconWidth(),
						       img.getIconHeight(),
						       BufferedImage.TYPE_INT_RGB);

		Graphics g = bImg.createGraphics();
		img.paintIcon(null,g,0,0);
		g.dispose();
		
		ImageIO.write(bImg, "jpg", file);
		
	    } catch(IOException e){
		e.printStackTrace();
	    } catch(ClassNotFoundException e){
		e.printStackTrace();   
	    }	    
	}
}

class ServerListener implements Runnable
{
    MyClient client;
    Scanner in;
    boolean run;

    ServerListener(MyClient givenClient, Socket givenSocket)
    {
	try{
	    this.client = givenClient;
	    in = new Scanner(new BufferedInputStream(givenSocket.getInputStream()));
	    run = true;
	} catch(IOException e) {
	    e.printStackTrace();
	}
    }

    public void run()
    {
	while(run){
		String serverInput = in.nextLine();
		client.handleServerInput(serverInput);
	}
    }
}
