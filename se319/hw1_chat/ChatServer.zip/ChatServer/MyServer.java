import java.util.Scanner;
import java.net.*;
import java.lang.Character;
import java.lang.Object;
import javax.swing.ImageIcon;
import javax.imageio.ImageIO;
import java.time.*;
import java.io.*;
import java.awt.*;
import java.awt.image.*;
import java.util.ArrayList;


public class MyServer
{
    ArrayList<BufferedOutputStream> clientStreams = new ArrayList<BufferedOutputStream>();
    int clientNum;
    ServerSocket sSocket;
    int messageCount;
    PrintWriter recordChat;
    
    public MyServer(){
	messageCount = 0;
	sSocket = null;
	clientNum = 0;

	try {
	    sSocket = new ServerSocket(4444);

      	File chatLog = new File("chat.txt");
       	if(!chatLog.exists()) chatLog.createNewFile();
   
        recordChat = new PrintWriter(new FileWriter(chatLog, true));
 
	} catch (IOException e) {
	    System.out.println("Server console: Could not listen on port: 4444");
	    System.exit(-1);
	}

	waitForClients();
    }

    public void waitForClients(){
	while(true) {
	    
	    Socket cSocket = null;
	    
	    try {
		cSocket = sSocket.accept();
		Thread t = new Thread( new ClientHandler(clientNum, cSocket, this));
		clientStreams.add(new BufferedOutputStream(cSocket.getOutputStream()));
		t.start();
		clientNum++;
	    } catch(IOException e){
		e.printStackTrace();
	    }
	}
    }


    public void broadcastMessage(int senderClientNum, String message)
    {
	PrintWriter out;

	System.out.println("Server: " + message.substring(2));
	
	for(int i = 0; i < clientStreams.size(); i++){
	    if(senderClientNum != i) {
		out = new PrintWriter(clientStreams.get(i));
		out.println(message);
		out.flush();
	    }
	}

	addToChatLog(message);
    }

    public void broadcastImage(int handlerNum, ImageIcon img){

	try{
	    for(int i = 0; i < clientStreams.size(); i++){
		if(i == handlerNum) continue;
	    
		ObjectOutputStream out = new ObjectOutputStream(clientStreams.get(i));
		out.writeObject(img);
	    }
	} catch (IOException e){
	    e.printStackTrace();
	}
    }

    public void addToChatLog(String message)
    {

	    recordChat.println("" + messageCount + " " + message.substring(2));

	    recordChat.flush();
	
	    messageCount++;
    }

    public void receiveImage(int handlerNum, String message, BufferedInputStream clientInput)
    {
	String filename = message.substring(message.indexOf(':') + 2);
	String senderName = message.substring(2, message.indexOf(':'));
	ImageIcon img;
	String hour = ("" + LocalTime.now()).substring(0,2);
	String minute = ("" + LocalTime.now()).substring(3,5);
	    
        String newFilename = filename.substring(0, filename.length() - 4) + '_' + senderName + '_' + hour + '_' + minute;
	    try{
		
		File file = new File("image/" + newFilename + ".jpg");
		file.createNewFile();

		ObjectInputStream objectIn = new ObjectInputStream(clientInput);
		img = (ImageIcon)objectIn.readObject();
		broadcastImage(handlerNum, img);

		//convert img to BufferedImage, so it can be written to file
		BufferedImage bImg = new BufferedImage(
		img.getIconWidth(),
		img.getIconHeight(),
		BufferedImage.TYPE_INT_RGB);
		
		Graphics g = bImg.createGraphics();
		// paint the Icon to the BufferedImage.
		img.paintIcon(null, g, 0,0);
		g.dispose();
		
		ImageIO.write(bImg, "jpg", file);
		
	    } catch(IOException e){
		e.printStackTrace();
	    } catch(ClassNotFoundException e){
		e.printStackTrace();   
	    }	    
	

    }

    public static void main(String[] args) throws IOException
    {
	MyServer server = new MyServer();
    }
}

 class ClientHandler implements Runnable
    {
	private int handlerNum;
	private Socket s;
	MyServer server;

	public ClientHandler(int num, Socket givenSocket, MyServer givenServer)
	{
	    this.handlerNum = num;
	    this.s = givenSocket;
	    this.server = givenServer;
	}

	public void run()
	{
	    Scanner clientInput;
	    PrintWriter out;
	    boolean cont = true;
	    int clientCommand;
	    
	    try {
		clientInput = new Scanner( new BufferedInputStream(s.getInputStream()));

		//start listening to client
		while(cont){
		    	String message;
			message = clientInput.nextLine();
		        
			clientCommand = Character.getNumericValue(message.charAt(0));
			
			switch(clientCommand){
			    case 1:
				server.broadcastMessage(handlerNum, message);
				break;
			    case 2:
				server.broadcastMessage(handlerNum, message);
				server.receiveImage(handlerNum, message, new BufferedInputStream(s.getInputStream()));
				break;
			    default:
				break;
			}
		}

	    } catch(IOException e){
		e.printStackTrace();
	    }
	}
    }
