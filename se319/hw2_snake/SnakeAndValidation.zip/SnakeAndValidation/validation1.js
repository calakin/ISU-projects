function validateForm()
{
    var form = document.forms["validationForm"];
    var first_name = form["firstName"].value;
    var last_name = form["lastName"].value;
    var gender = form["gender"].value;
    var state = form["state"].value;
    var wrong = false;
    
    if(first_name == ""){
	alert("First name must be filled out.");
	show_wrong(1);
	wrong = true;
    } else if(!isAlphanumeric(first_name)){
	alert("First name must contain only alphabetic or numeric characters.");
	show_wrong(1);
	wrong = true;
    } else {
	show_correct(1);
    }
    
    if(last_name == ""){
	alert("Last name must be filled out.");
	wrong = true;
	show_wrong(2);
    }else if(!isAlphanumeric(last_name)){
	alert("Last name must contain only alphabetic or numeric characters.");
	wrong = true;
	show_wrong(2);
    }else{
	show_correct(2);
    }
    
    if(gender == ""){
	alert("Gender must be filled out.");
	wrong = true;
	show_wrong(3);
    } else {
	show_correct(3);
    }
    
    if(state == ""){
	alert("State must be filled out.");
	wrong = true;
	show_wrong(4);
    } else {
	show_correct(4);
    }

    if(wrong){
	return false;
    } else {
	localStorage.setItem("storedState", state);
	window.location.href = "./validation2.html";
	return true;
    }
    
    function isAlphanumeric(input)  
    {  
	var letterNumber = /^[0-9a-zA-Z]+$/;  
	if(input.match(letterNumber)){  
	       return true;  
	} else {      
	       return false;   
	}
    } 
}

function show_wrong(numImg) {
  var img = document.getElementById("img" + numImg);
  img.src = "./wrong.png";
  img.style.visibility = "visible"; 
}
function show_correct(numImg) {
    var img = document.getElementById("img" + numImg);
  img.src = "./correct.png";
  img.style.visibility = "visible";
}
