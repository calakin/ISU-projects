function validateForm()
{
    var form = document.forms["contactInfoForm"];
    var email = form["email"].value;
    var phone = form["phone"].value;
    var address = form["address"].value;
    var wrong = false;

    <!-- Validate email -->
    if(email == ""){
	alert("Email must be filled out.");
	show_wrong(1);
	wrong = true;
    } else if(!emailFormat(email)){
	alert("Must be in the form xxx@xxx.xxx, using only alphanumeric characters and only 2-3 characters in the last group.");
	show_wrong(1);
	wrong = true;
    } else {
	show_correct(1);
    }

    <!-- validate phone -->
    if(!(phone == "") && !phoneFormat(phone)){
	alert("Must be in the format xxx-xxx-xxxx or xxxxxxxxxx, where x is numeric");
	show_wrong(2);
	wrong = true;
    }else{
	show_correct(2);
    }

    <!-- validate address -->
    if(address == ""){
	alert("Address must be filled out.");
	wrong = true;
	show_wrong(3);
    } else if(!addressFormat(address)){
	alert("Must be in the form city,state using only letters");
	show_wrong(3);
	wrong = true;
    } else {
	show_correct(3);
    }

    if(wrong){
	return false;
    } else {
	localStorage.setItem("storedAddress", address);
	window.location.href = "./locationGoogleMaps.html";
	return true;
    }
}

    function emailFormat(input)  
    {  
	var letterNumber = "^[A-Za-z0-9]+@[A-Za-z0-9]+\.[a-z]{2,3}$";  
	if(input.match(letterNumber)){  
	       return true;  
	} else {      
	       return false;   
	}
    }

    function phoneFormat(input)  
    {  
	var letterNumber ="^[0-9]{3}-[0-9]{3}-[0-9]{4}$|^[0-9]{10}$";  
	if(input.match(letterNumber)){  
	       return true;  
	} else {      
	       return false;   
	}
    }

    function addressFormat(input)  
    {  
	var letterNumber = "^[a-zA-Z]+,[a-zA-Z]+$";  
	if(input.match(letterNumber)){  
	       return true;  
	} else {      
	       return false;   
	}
    } 

function show_wrong(numImg) {
  var img = document.getElementById("img" + numImg);
  img.src = "./wrong.png";
  img.style.visibility = "visible"; 
}
function show_correct(numImg) {
    var img = document.getElementById("img" + numImg);
  img.src = "./correct.png";
  img.style.visibility = "visible";
}
