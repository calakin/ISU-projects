var current_direction, timer, current_x, current_y;
var draw_distance = 1;
var line_thickness = 4;

function start_timer(){
    current_y = (document.getElementById("my_canvas").height)/2;
    current_x = 0;
    current_direction = 90;

    //draw the first rectangle
    var canvas = document.getElementById("my_canvas");
    var ctx = canvas.getContext("2d");
    ctx.fillStyle = "#FF0000";
    ctx.fillRect(current_x, current_y, draw_distance, line_thickness);
    current_x += draw_distance;
    
    timer = setInterval( function() {draw(current_direction)} , 25);
}

function stop_timer()
{
    clearInterval(timer);
}

function draw(){  
    var canvas = document.getElementById("my_canvas");
    var ctx = canvas.getContext("2d");
    ctx.fillStyle = "#FF0000";

    //starts off drawing to the right at 2 pixels per second, with line width of 4
    var x_dim = draw_distance;
    var y_dim = line_thickness;

    var x_adjustment = x_dim;
    var y_adjustment = 0;

    //interpret direction (switch width/height appropriately, update 
    switch(current_direction) {
    case(0):
	y_dim = -draw_distance;
	y_adjustment = y_dim;
	x_dim = line_thickness;
	x_adjustment = 0;
	break;
    case(90):
	y_dim = line_thickness;
	y_adjustment = 0;
	x_dim = draw_distance;
	x_adjustment = x_dim;
	break;
    case(180):
	y_dim = draw_distance;
	y_adjustment = y_dim;
	x_dim = line_thickness;
	x_adjustment = 0;
	break;
    case(270):
	y_dim = line_thickness;
	y_adjustment = 0;
	x_dim = -draw_distance;
	x_adjustment = x_dim;
	break;
    default:
	break;
     }

    //check if new addition (new x and y) would touch boundary (if so, stop_timer())
    if(current_x + x_adjustment < 0 ||
       current_x + x_adjustment >= canvas.width ||
       current_y + y_adjustment < 0 ||
       current_y + y_adjustment >= canvas.height)
    {
	stop_timer();
    }
    //draw new addition
    ctx.fillRect(current_x, current_y, x_dim, y_dim);
    current_x += x_adjustment;
    current_y += y_adjustment;
}

function turn_left()
{
    current_direction = current_direction + 270;

     //represents degrees, modding allows it to be interpreted easily
    current_direction = current_direction % 360;

    if (current_direction == 0) {
	current_x -= line_thickness
    }
}

function turn_right()
{
    current_direction = current_direction + 90;

     //represents degrees, modding allows it to be interpreted easily
    current_direction = current_direction % 360;

    if (current_direction == 270) {
	current_y -= line_thickness
    }
}
