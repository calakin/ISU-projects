function validateLogin()
{
    var username = document.forms["loginForm"]["username"].value;
    var password = document.forms["loginForm"]["password"].value;
    
    if (username == "admin") {
	if (password == "admin") {
	    success(username);
	    window.location = "booksLibrary.html";
	} else {
	    alert("Incorrect username/password combination");
	    return false;
	}
    } else if(username.charAt(0) == "U") {
	success(username);
	window.location = "booksLibrary.html";
    } else {
	alert("Incorrect username/password combination");
	return false;
    }
}

function success(givenUsername)
{
    $.ajax({type:"POST",
	    url:"login.php",
	    data: {username: givenUsername}
	   });
}
