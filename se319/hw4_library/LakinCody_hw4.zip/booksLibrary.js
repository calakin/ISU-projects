class Book {
    constructor(givenID, givenAvailable, givenBorrowedBy){
	this.ID = givenID;
	this.borrowedBy = givenBorrowedBy;
	this.available = givenAvailable;
	this.shelfNum = (parseInt(givenID) %4);
	this.name = "B" + this.ID;

	var shelfNames = ["Art","Science","Sport","Literature"];
	this.shelfName = shelfNames[this.shelfNum];
    }

    setName(givenName)
    {
	this.name = givenName;
    }

    getDetails()
    {
	var borrowed = this.available == 0 ? "Yes" : "No";
	var details = "";
	details += "Name:     " + this.name + "<br>";
	details += "ID:       " + this.ID + "<br>";
	details += "Shelf:    " + this.shelfName + "<br>";
	details += "Borrowed: " + borrowed + "<br>";
	details += "Borrower: " + this.borrowedBy + "<br>";

	return details;
    }
}

class Shelf {
    constructor(shelfNumber, shelfName){
	this.name = shelfName;
	this.number = shelfNumber;

	this.books = [];	
    }
}

class Library {
    constructor(elementId){

	this.bookList = [];
	this.readBooks();
	
	var Art = new Shelf(0, "Art");
	var Science = new Shelf(1, "Science");
	var Sport = new Shelf(2, "Sport");
	var Literature = new Shelf(3, "Literature");	
	this.shelves = [Art, Science, Sport, Literature];
	this.fillShelves();

	this.user = ($.ajax({type:"GET",
			     url:"get_user.php",
			     async: false,
			    }).responseText);

	this.View = {
	    newBookNameInput : {id: "newBookNameInput", type: "text", placeholder: "Book Name"},
	    shelfNameInput : {id: "shelfNameInput", type: "text", placeholder: "Shelf (Art, Science...)"},
	    addBookButton : {id: "addBookButton", type: "button", value:"Add Book", onclick:""},
            container : document.getElementById(elementId)
	};

	this.Controller = {
            viewClickHandler : function(e) {
		let target = e.target;
		if (target.id == "addBookButton") {
		    this.addBook();
		} else if (target.id.substr(0,4) == "book") {
		    this.clickBook(target.id);
		}
	    }
	}
	
	this.renderView();
	this.renderBorrowed();
    }

    addBook()
    {
	var book = document.getElementById("newBookNameInput").value;
	var shelf = document.getElementById("shelfNameInput").value;

	var i, length;
	length = this.shelves.length;
	for(i = 0; i < length; i++){
	    if(this.shelves[i].name == (shelf)){
		var ID = "" + (parseInt(this.shelves[i].books[this.shelves[i].books.length - 1].ID) + 4);

		while(ID.length < 3){
		    ID = "0" + ID;
		}
		
		var available = 1;
		var borrowedBy = "";
		var newBook = new Book(ID, available, borrowedBy);
		this.shelves[i].books.push(newBook);
		this.bookList.push(newBook);
		this.shelves[i].books[this.shelves[i].books.length - 1].setName(book);

		var s;
		if (borrowedBy == "") {
		    s = "" + ID + " " + available + "\n";
		} else {
		    s = "" + ID + " " + available + " " + borrowedBy + "\n";
		}
		
		$.ajax({type:"POST",
			url:"getbooks.php",
			async: false,
			data: {command: "add", new_line: s}
		       });
		    
		
		this.renderView();
		return;
	    }
	}
	alert("Invalid Shelf Name.");
    }

    borrowBook(book)
    {
	book.available = 0;
	book.borrowedBy = this.user;

	var s = "" + book.ID + " " + book.available + " " + book.borrowedBy;
	
	$.ajax({type:"POST",
		url:"getbooks.php",
		async: false,
		data: {command: "borrow", new_line: s}
	       });

	this.renderBorrowed();
    }

    returnBook(book)
    {
	book.available = 1;
	book.borrowedBy = "";

	var s = "" + book.ID + " " + book.available;
	
	$.ajax({type:"POST",
		url:"getbooks.php",
		async: false,
		data: {command: "return", new_line: s}
	       });
	
	this.renderBorrowed();
    }

    renderBorrowed()
    {
	var i, length;
	length = this.bookList.length;
	alert("!" + this.bookList[19].borrowedBy + "!");
	for(i = 0; i < length; i++){
	    var book = this.bookList[i];
	    if(book.borrowedBy == this.user){
		//alert("book" + book.ID);
		document.getElementById("book" + book.ID).style.backgroundColor = "red";
	    } else {
		//alert("book" + book.ID);
		document.getElementById("book" + book.ID).style.backgroundColor = "white";
	    }
	}
    }
    
    clickBook(id)
    {
	//get the book that was clicked
	var ID = id.substr(4, 3);
	var book;
	var i, length;
	length = this.bookList.length;
	for(i = 0; i < length; i++){
	    if(this.bookList[i].ID == ID){
		book = this.bookList[i];
	    }
	}

	if(this.user == "librarian"){
	    document.getElementById("details").innerHTML = book.getDetails();
	} else {
	    //if book available, borrow
	    if(book.available == 1) {

		var numBorrowed = 0;
		for(i = 0; i < length; i++){
		    if(this.bookList[i].borrowedBy == this.user) numBorrowed++;
		}
		
		if(numBorrowed < 2){
		    this.borrowBook(book);
		} else {
		    alert("You cannot borrow more books until you return one.");
		}
	    } else {
		if(this.user == book.borrowedBy){
		    this.returnBook(book);
		} else {
		    alert("That book is currently unavailable.");
		}
	    }
	}
    }
    
    fillShelves()
    {
	var length = this.bookList.length;
	var index;
	for(index = 0; index < length; index++){
	    var book = this.bookList[index];
	    this.shelves[book.shelfNum].books.push(book);
	}
    }
    
    readBooks()
    {
	//populate shelves with books
	var readBooks = ($.ajax({type:"POST",
				 url:"getbooks.php",
				 async: false,
				 data: {command: "read"},
				}).responseText);

	var strings = [];
	var index = 0;
	var start = 0;
	var numLines = 1;
	while(index < readBooks.length){
	    if(readBooks.charAt(index) == "\n"){
		numLines++;
		strings.push(readBooks.substring(start, index));
		start = index + 1;
	    }
	    index++;
	}
	if(readBooks.charAt(readBooks.length) != "\n") {
	    strings.push(readBooks.substring(start, readBooks.length));
	}

	this.trim(strings);

	var arrLength = strings.length;
	for(index = 0; index < arrLength; index++){
	    var length = strings[index].length;
	    if(length > 4) {
		
		var id = strings[index].substr(0,3);
		var available = strings[index].substr(4, 1);
		var borrowedBy;
		
		if(length > 6){
		    borrowedBy = strings[index].substr(6, length - 7);
		} else {
		    borrowedBy = "";
		}
		this.bookList.push(new Book(id, available, borrowedBy));
	    }
	}
    }

    trim(strings)
    {
	if(strings[strings.length - 1].length < 5) strings.pop();
	if(strings[strings.length - 1].length < 5) this.trim(strings);
    }
    
    //update the view
    renderView(){
	this.attachHandlers();
        let htmlString = this.createHTMLforView();
        this.View.container.innerHTML = htmlString;
        return this;
    }

    //
    // attachButtonHandlers
    // determines what action is taken when a button is clicked
    // makes sure that when we click on a button or cell, the "this"
    // reference is fixed to that cell
    //
    attachHandlers() {
       this.View.container.onclick 
          = this.Controller.viewClickHandler.bind(this);
    }

    button0Handler() {
	this.current += "0";
	this.View.textRow.value = this.current;
	this.renderView();
    }
    
    //
    // createHTMLforView
    // Utility. creates HTML formatted text for the entire view
    //
    createHTMLforView() {
	var s;

	s = "<p>You are logged in as: " + this.user + "</p>";

	//for the table, make it so it only updates when needed
	s += "<table id=\"myTable\" border=2>"

	s += "<tr>";
	
	var i, j;
	var length = this.shelves.length;
	var max = this.shelves[0].books.length;
	for(i = 0; i < length; i++) {
	    s += "<th>" + this.shelves[i].name + "</th>";

	    if(this.shelves[i].length > max) max = this.shelves[i].length;
	}

	s += "</tr>";

	for(j = 0; j < max; j++){
	    s += "<tr>"

	    for(i = 0; i < length; i++){
		s += "<td>";

		if(j < this.shelves[i].books.length){
		    s += "<div ";
		    s += "id=\"book" + this.shelves[i].books[j].ID + "\" ";
		    s += "onclick=\"\">";
		    s += this.shelves[i].books[j].name;
		    s += "</div>";
		}
		
		s += "</td>";
	    }
	    
	    s += "</tr>";
	}
	
	s += "</td></tr>";
	s += "</tr></td></table><br>";
	//

	if(this.user == "librarian"){
	    s += "<div id=\"details\"></div>";

	    s += "<input ";
	    s += " id=\"" + this.View.newBookNameInput.id + "\"";
	    s += " type=\"" + this.View.newBookNameInput.type + "\"";
	    s += " placeholder= \"" + this.View.newBookNameInput.placeholder + "\"";
	    s += ">";

	    s += "<input ";
	    s += " id=\"" + this.View.shelfNameInput.id + "\"";
	    s += " type=\"" + this.View.shelfNameInput.type + "\"";
	    s += " placeholder= \"" + this.View.shelfNameInput.placeholder + "\"";
	    s += ">";

	    s += "<input ";
	    s += " id=\"" + this.View.addBookButton.id + "\"";
	    s += " type=\"" + this.View.addBookButton.type + "\"";
	    s += " value= \"" + this.View.addBookButton.value + "\"";
	    s += " onclick= \"" + this.View.addBookButton.onclick + "\"";
	    s += ">";
	}
	return s;
    }
}
