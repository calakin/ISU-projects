<?php
session_start();

echo $_SESSION['username'] === "admin" ? "librarian" : $_SESSION['username'];

?>