This project is for SE319's hw4. It fully complies with the assignment spec. There is only one known error, and it is that an added book's name changes to a default name upon refreshing the page. This is because I do not store book names in books.txt. It would be easily fixed, it would just take some time, which I don't have.

