<?php

function read_books() {
	 $book_list = file_get_contents("./books.txt");

	 return $book_list;
}

function save_books($book_list) {
	 file_put_contents('./books.txt', $book_list);
}

$command = $_POST['command'];

if($command === "read") {
     $book_list = read_books();
     echo $book_list;
     
} else if($command === "add") {
     $new_line = $_POST['new_line'];
     
     $book_list = read_books();

     if($book_list[strlen($book_list) - 1] == "\r\n"){
     	$new_book_list = $book_list . $new_line;
     } else {
       	$new_book_list = $book_list . "\r\n" . $new_line;
     }

     save_books($new_book_list);

} else if($command === "borrow" || $command === "return") {

     $new_line = $_POST['new_line'];
     
     $book_list = read_books();

     $i = 0;
     $length = strlen($book_list);
     for($i = 0; $i < $length; $i++){
     	    if(strcmp(substr($book_list, (0 + $i), 3), substr($new_line, 0, 3)) == 0){
	    	$line_start = $i;

     		while($i < $length && $book_list[$i] != "\n"){
     	      		 $i++;
     		}
     		$line_end = $i;

     		$first_half = substr($book_list, 0, (0 + $line_start));

     		if($length > $line_end){
       			   $second_half = substr($book_list, $line_end + 1, $length - ($line_end + 1));
			   $new_book_list = $first_half . $new_line . "\r\n" . $second_half;

     			   save_books($new_book_list);
			   break;
     		} else {
			$second_half = "";
			$new_book_list = $first_half . $new_line . $second_half;

			save_books($new_book_list);
			break;
		}
	    }
     }



}
?>
